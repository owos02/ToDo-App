﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1.Seiten;

namespace WindowsFormsApplication1
{
    public partial class Startseite : Form
    {
        public bool check = false;
        public Startseite()
        {
            InitializeComponent();
            MessageBox.Show("Das aktuelle verzeichnis:" + Environment.CurrentDirectory);
        }

        private void Creator_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void KontaktButton_Click(object sender, EventArgs e)
        {
            var OpenNew = new Kontakte();
            this.Hide();
            OpenNew.ShowDialog();
            this.Show();
        }
        private void TODOButton_Click(object sender, EventArgs e)
        {
            var OpenNew = new TODO_Liste();
            this.Hide();
            OpenNew.ShowDialog();
            this.Show();
        }
        private void Startseite_Load(object sender, EventArgs e)
        {
            
        }

        private void Nam1_Click(object sender, EventArgs e)
        {

        }
    }
}
