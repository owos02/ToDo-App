﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class TODO_Liste : Form
    {
        public TODO_Liste()
        {
            InitializeComponent();
        }

        private void TODO_Liste_Load(object sender, EventArgs e)
        {
            // TODO: Diese Codezeile lädt Daten in die Tabelle "kundenDataSet.Kunden". Sie können sie bei Bedarf verschieben oder entfernen.
            this.kundenTableAdapter.Fill(this.kundenDataSet.Kunden);
            kontzal.Text = Convert.ToString(kundenDataSet.Kunden.Count);
            TreeNode Basis = new TreeNode("TODO-Listen");
            treeView1.Nodes.Add(Basis);
            TreeNode SubBasis1 = new TreeNode("Schule");
            treeView1.Nodes[0].Nodes.Add(SubBasis1);
            TreeNode SubBasis2 = new TreeNode("Privat");
            treeView1.Nodes[0].Nodes.Add(SubBasis2);
            treeView1.ExpandAll();
            treeView1.SelectedNode = SubBasis2;

        }

        private void kundenBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.kundenBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.kundenDataSet);

        }

        private void nameListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void NewTODO_Click(object sender, EventArgs e)
        {
            if (newTodoBox.Visible == true)
            {
                newTodoBox.Visible = false;
                NewTODO.Text = "Neue TODO-Liste";
            }
            else {
                newTodoBox.Visible = true;
                NewTODO.Text = "Abbrechen";
            };
        }

        private void NewNameSave_Click(object sender, EventArgs e)
        {
            TreeNode NewTodo = new TreeNode(NewName.Text);
            treeView1.Nodes[0].Nodes.Add(NewTodo);
            newTodoBox.Visible = false;

        }

        private void TODO_DONE_CheckedChanged(object sender, EventArgs e)
        {

        }
        
        private void NewEntry_Click(object sender, EventArgs e)
        {
            if(!(Title.Text.Trim() == ""))
            {
                TreeNode NewTodo = new TreeNode(Title.Text);

                TreeNode PRIO = new TreeNode("Priorität");
                TreeNode SDate = new TreeNode("Start Datum");
                TreeNode EDate = new TreeNode("End Datum");
                TreeNode GenTeiln = new TreeNode("Teilnehmer");
                TreeNode Desc = new TreeNode("Beschreibung");

                TreeNode S_PRIO = new TreeNode(Convert.ToString(Priority.Value));
                TreeNode S_SDate = new TreeNode(StartDate.Text);
                TreeNode S_EDate = new TreeNode(EndDate.Text);
                TreeNode S_Desc = new TreeNode(Description.Text);

                //TreeNode S_GenTeiln = new TreeNode('Teilnehmer');
                   //Muss anders hinzugefügt werden
                treeView1.Nodes[treeView1.SelectedNode.Parent.Index].Nodes[treeView1.SelectedNode.Index].Nodes.Add(NewTodo);

                NewTodo.Nodes.Add(PRIO);
                NewTodo.Nodes.Add(SDate);
                NewTodo.Nodes.Add(EDate);
                NewTodo.Nodes.Add(GenTeiln);
                NewTodo.Nodes.Add(Desc);
                
                PRIO.Nodes.Add(S_PRIO);
                SDate.Nodes.Add(S_SDate);
                EDate.Nodes.Add(S_EDate);
                if(!(Description.Text.Trim() == "")) Desc.Nodes.Add(S_Desc);
            }
            else
            {
                MessageBox.Show("Es muss ein Titel angegeben werden!");
            }

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (!(treeView1.SelectedNode.Text == "TODO-Listen" || treeView1.SelectedNode.Text == "Schule" || treeView1.SelectedNode.Text == "Privat"))
            {
                treeView1.SelectedNode.Remove();
            }
            else
                MessageBox.Show("Du darfst diesen Punkt nicht löschen!");
            
        
        }

        private void SelectContact_Click(object sender, EventArgs e)
        {
            


        }

        private void NewName_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveAll_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jetzt wird alles gespeichert!");
            TODO_Liste.ActiveForm.Close();
        }

        private void editToDo_Click(object sender, EventArgs e)
        {
            if(editEintrag.Visible == false)
            {
                //if(TreeView ausgewählt){
                editToDo.Text = "Abbrechen";
                editEintrag.Visible = true;


                //}
            }
            else
            {
                editEintrag.Visible = false;
                editToDo.Text = "Bearbeiten";
            }

        }
    }
}
