﻿namespace WindowsFormsApplication1.Seiten
{
    partial class Kontakte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.kundenDataSet = new WindowsFormsApplication1.KundenDataSet();
            this.kundenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kundenTableAdapter = new WindowsFormsApplication1.KundenDataSetTableAdapters.KundenTableAdapter();
            this.tableAdapterManager = new WindowsFormsApplication1.KundenDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.kundenDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kundenBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label1.ForeColor = System.Drawing.Color.Azure;
            this.label1.Location = new System.Drawing.Point(7, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kontaktliste";
            // 
            // kundenDataSet
            // 
            this.kundenDataSet.DataSetName = "KundenDataSet";
            this.kundenDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // kundenBindingSource
            // 
            this.kundenBindingSource.DataMember = "Kunden";
            this.kundenBindingSource.DataSource = this.kundenDataSet;
            // 
            // kundenTableAdapter
            // 
            this.kundenTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.KundenTableAdapter = this.kundenTableAdapter;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApplication1.KundenDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Kontakte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Kontakte";
            this.Text = "2_Kontakte";
            this.TopMost = true;
            this.Load += new System.EventHandler(this._2_Kontakte_Load);
            ((System.ComponentModel.ISupportInitialize)(this.kundenDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kundenBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private KundenDataSet kundenDataSet;
        private System.Windows.Forms.BindingSource kundenBindingSource;
        private KundenDataSetTableAdapters.KundenTableAdapter kundenTableAdapter;
        private KundenDataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}